<?php 
 // created: 2016-09-20 18:02:54
$mod_strings['LBL_CIF'] = 'CIF/NIF';
$mod_strings['LBL_COLEGIO'] = 'Colegio';
$mod_strings['LBL_CURSO'] = 'Curso';
$mod_strings['LBL_ASIGNATURAS'] = 'Asignaturas';
$mod_strings['LBL_ALUMNO'] = 'Alumno(Sin DNI)';
$mod_strings['LBL_DESCRIPCION_RECIBO'] = 'Descripcion recibo';
$mod_strings['LBL_RECIBOSINO'] = 'Recibo Si/No';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Recibos';
$mod_strings['LBL_CANTIDAD_RECIBO'] = 'Cantidad recibo';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Recibos';
$mod_strings['LBL_ACCOUNTS_ACCOUNTS_SUBPANEL_TITLE'] = 'Familia';
$mod_strings['LBL_NUMERO'] = 'Numero';
$mod_strings['LBL_ACCOUNTS_FACT_FACTURAS_SUBPANEL_TITLE'] = 'LBL_ACCOUNTS_FACT_FACTURAS_SUBPANEL_TITLE';
$mod_strings['LBL_GRUPO'] = 'Grupo';
$mod_strings['LBL_CON_CONTRATOS_ACCOUNTS_FROM_CON_CONTRATOS_TITLE'] = 'Contratos';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Normas de clases particulares';
$mod_strings['LBL_NCP_FIRMADO'] = 'Firmado';
$mod_strings['LBL_NCP_ESCANEADO'] = 'Escaneado';
$mod_strings['LBL_NCP_ENTREGADO'] = 'Entregado';

?>
