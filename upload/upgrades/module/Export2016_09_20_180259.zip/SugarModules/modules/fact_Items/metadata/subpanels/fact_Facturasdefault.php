<?php
// created: 2012-02-28 18:40:30
$subpanel_layout['list_fields'] = array (
  'updown_button' => 
  array (
    'widget_class' => 'SubPanelUpDownButton',
    'module' => 'fact_Productos',
    'width' => '1%',
    'default' => true,
    'sortable' => false,
  ),
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubpanelItemDescription',
    'width' => '25%',
    'default' => true,
    'sortable' => false,
  ),
  'cantidad' => 
  array (
    'width' => '8%',
    'vname' => 'LBL_CANTIDAD',
    'default' => true,
    'sortable' => false,
  ),
  'precio_ud' => 
  array (
    'width' => '8%',
    'vname' => 'LBL_PRECIO_UD',
    'default' => true,
    'sortable' => false,
  ),
  'descuento' => 
  array (
    'width' => '8%',
    'vname' => 'LBL_DESCUENTO',
    'default' => true,
    'sortable' => false,
  ),
  'total_impuesto' => 
  array (
    'width' => '8%',
    'vname' => 'LBL_TOTAL_IMPUESTO',
    'currency_format' => true,
    'default' => true,
    'sortable' => false,
    'widget_class' => 'SubpanelTax',
  ),
  'total_retencion' => 
  array (
    'width' => '10%',
    'vname' => 'LBL_TOTAL_RETENCION',
    'currency_format' => true,
    'default' => true,
    'sortable' => false,
    'widget_class' => 'SubpanelTax',
  ),
  'total_antes' => 
  array (
    'width' => '15%',
    'vname' => 'LBL_TOTAL_ANTES',
    'currency_format' => true,
    'default' => true,
    'sortable' => false,
  ),
  'edit_button' => 
  array (
    'widget_class' => 'SubPanelQuickItem',
    'module' => 'fact_Productos',
    'width' => '5%',
    'default' => true,
    'sortable' => false,
  ),
  'remove_button' => 
  array (
    'widget_class' => 'SubPanelDeleteRelatedButton',
    'module' => 'fact_Productos',
    'width' => '5%',
    'default' => true,
    'sortable' => false,
  ),
  'description' => 
  array (
    'vname' => 'LBL_NAME',
    'usage' => 'query_only',
  ),
  'impuesto' => 
  array (
    'usage' => 'query_only',
  ),
  'tipo_repercutido' => 
  array (
    'usage' => 'query_only',
  ),
  'unidad_custom' => 
  array (
    'usage' => 'query_only',
  ),
  'unidad' => 
  array (
    'usage' => 'query_only',
  ),
  'retencion' => 
  array (
    'usage' => 'query_only',
  ),
);
?>
