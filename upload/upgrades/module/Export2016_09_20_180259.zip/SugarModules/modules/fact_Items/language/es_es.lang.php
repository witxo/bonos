<?php 
 // created: 2016-09-20 18:02:58
$mod_strings['LBL_TIPO'] = 'tipo';

?>
