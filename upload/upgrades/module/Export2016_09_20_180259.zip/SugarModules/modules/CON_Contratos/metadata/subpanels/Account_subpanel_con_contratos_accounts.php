<?php
// created: 2016-08-24 20:27:12
$subpanel_layout['list_fields'] = array (
  'edit_button' => 
  array (
    'vname' => 'LBL_EDIT_BUTTON',
    'widget_class' => 'SubPanelEditButton',
    'module' => 'CON_Contratos',
    'width' => '4%',
    'default' => true,
  ),
  'remove_button' => 
  array (
    'vname' => 'LBL_REMOVE',
    'widget_class' => 'SubPanelRemoveButton',
    'module' => 'CON_Contratos',
    'width' => '5%',
    'default' => true,
  ),
  'accion' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_ACCION',
    'width' => '10%',
  ),
  'tipo' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_TIPO',
    'width' => '10%',
  ),
  'fecha_inicio' => 
  array (
    'type' => 'date',
    'vname' => 'LBL_FECHA_INICIO',
    'width' => '10%',
    'default' => true,
  ),
  'horas' => 
  array (
    'type' => 'decimal',
    'vname' => 'LBL_HORAS',
    'width' => '10%',
    'default' => true,
  ),
  'escaneado' => 
  array (
    'type' => 'bool',
    'default' => true,
    'vname' => 'LBL_ESCANEADO',
    'width' => '10%',
  ),
  'enviado' => 
  array (
    'type' => 'bool',
    'default' => true,
    'vname' => 'LBL_ENVIADO',
    'width' => '10%',
  ),
  'firmado' => 
  array (
    'type' => 'bool',
    'default' => true,
    'vname' => 'LBL_FIRMADO',
    'width' => '10%',
  ),
  'categoria' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_CATEGORIA',
    'width' => '10%',
  ),
  'con_contratos_accounts_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'vname' => 'LBL_CON_CONTRATOS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
    'id' => 'CON_CONTRATOS_ACCOUNTSACCOUNTS_IDA',
    'width' => '10%',
    'default' => true,
    'widget_class' => 'SubPanelDetailViewLink',
    'target_module' => 'Accounts',
    'target_record_key' => 'con_contratos_accountsaccounts_ida',
  ),
  'observaciones' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'vname' => 'LBL_OBSERVACIONES',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
);