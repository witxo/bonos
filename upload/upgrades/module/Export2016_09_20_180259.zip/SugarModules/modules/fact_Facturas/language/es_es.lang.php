<?php 
 // created: 2016-09-20 18:02:58
$mod_strings['LBL_GASTO_SI_NO'] = 'Gasto (Si/No)';
$mod_strings['LBL_INGRESO_SI_NO'] = 'Ingreso (Si/No)';
$mod_strings['LBL_NRECIBO'] = 'Nº Recibo';
$mod_strings['LBL_CLASIFICACION'] = 'Clasificación';
$mod_strings['LBL_FACT_ITEMS_SUBPANEL_TITLE'] = 'LBL_FACT_ITEMS_SUBPANEL_TITLE';
$mod_strings['LBL_MODO_PAGO'] = 'Modo de pago';
$mod_strings['LBL_GRUPO'] = 'Grupo';
$mod_strings['LBL_TYPE'] = 'Tipo:';
$mod_strings['LBL_FECHA_EMISION'] = 'Fecha';

?>
