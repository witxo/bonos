<?php
// created: 2011-10-19 20:43:13
$dictionary["Account"]["fields"]["stive_ordenes_accounts"] = array (
  'name' => 'stive_ordenes_accounts',
  'type' => 'link',
  'relationship' => 'stive_ordenes_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
);
