<?php
 // created: 2016-08-24 21:08:59
$dictionary['Account']['fields']['ncp_entregado_c']['labelValue']='Entregado';

 ?>