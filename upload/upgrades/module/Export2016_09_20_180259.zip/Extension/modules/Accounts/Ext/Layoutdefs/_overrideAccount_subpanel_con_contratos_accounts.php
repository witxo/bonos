<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['con_contratos_accounts']['override_subpanel_name'] = 'Account_subpanel_con_contratos_accounts';
?>