<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['accounts_fact_facturas']['override_subpanel_name'] = 'Accountdefault';
?>