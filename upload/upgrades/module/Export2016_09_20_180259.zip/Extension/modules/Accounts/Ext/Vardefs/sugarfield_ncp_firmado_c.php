<?php
 // created: 2016-08-24 21:08:26
$dictionary['Account']['fields']['ncp_firmado_c']['labelValue']='Firmado';

 ?>