<?php
// created: 2011-10-19 19:50:52
$layout_defs["Accounts"]["subpanel_setup"]["stive_ordenes_accounts"] = array (
  'order' => 100,
  'module' => 'STIVE_Ordenes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
  'get_subpanel_data' => 'stive_ordenes_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2011-10-19 19:54:23
$layout_defs["Accounts"]["subpanel_setup"]["stive_ordenes_accounts"] = array (
  'order' => 100,
  'module' => 'STIVE_Ordenes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
  'get_subpanel_data' => 'stive_ordenes_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2011-10-19 20:05:58
$layout_defs["Accounts"]["subpanel_setup"]["stive_ordenes_accounts"] = array (
  'order' => 100,
  'module' => 'STIVE_Ordenes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
  'get_subpanel_data' => 'stive_ordenes_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2011-10-19 20:23:53
$layout_defs["Accounts"]["subpanel_setup"]["stive_ordenes_accounts"] = array (
  'order' => 100,
  'module' => 'STIVE_Ordenes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
  'get_subpanel_data' => 'stive_ordenes_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2011-10-19 20:33:37
$layout_defs["Accounts"]["subpanel_setup"]["stive_ordenes_accounts"] = array (
  'order' => 100,
  'module' => 'STIVE_Ordenes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
  'get_subpanel_data' => 'stive_ordenes_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2011-10-19 20:35:17
$layout_defs["Accounts"]["subpanel_setup"]["stive_ordenes_accounts"] = array (
  'order' => 100,
  'module' => 'STIVE_Ordenes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
  'get_subpanel_data' => 'stive_ordenes_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2011-10-19 20:43:13
$layout_defs["Accounts"]["subpanel_setup"]["stive_ordenes_accounts"] = array (
  'order' => 100,
  'module' => 'STIVE_Ordenes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_STIVE_ORDENES_ACCOUNTS_FROM_STIVE_ORDENES_TITLE',
  'get_subpanel_data' => 'stive_ordenes_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
