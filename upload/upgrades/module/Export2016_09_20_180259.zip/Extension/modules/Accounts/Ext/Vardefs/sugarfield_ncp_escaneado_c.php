<?php
 // created: 2016-08-24 21:07:33
$dictionary['Account']['fields']['ncp_escaneado_c']['labelValue']='Escaneado';

 ?>