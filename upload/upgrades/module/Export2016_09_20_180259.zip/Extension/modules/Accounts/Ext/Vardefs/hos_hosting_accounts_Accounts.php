<?php
// created: 2012-11-14 11:25:58
$dictionary["Account"]["fields"]["hos_hosting_accounts"] = array (
  'name' => 'hos_hosting_accounts',
  'type' => 'link',
  'relationship' => 'hos_hosting_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_HOS_HOSTING_ACCOUNTS_FROM_HOS_HOSTING_TITLE',
);
