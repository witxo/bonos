<?php
// created: 2014-01-15 19:06:15
$dictionary["Account"]["fields"]["accounts_accounts"] = array (
  'name' => 'accounts_accounts',
  'type' => 'link',
  'relationship' => 'accounts_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_FROM_ACCOUNTS_L_TITLE',
);
$dictionary["Account"]["fields"]["accounts_accounts"] = array (
  'name' => 'accounts_accounts',
  'type' => 'link',
  'relationship' => 'accounts_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_FROM_ACCOUNTS_R_TITLE',
);
