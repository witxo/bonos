<?php
//auto-generated file DO NOT EDIT
$layout_defs['fact_Facturas']['subpanel_setup']['fact_items']['override_subpanel_name'] = 'fact_Facturasdefault';
?>