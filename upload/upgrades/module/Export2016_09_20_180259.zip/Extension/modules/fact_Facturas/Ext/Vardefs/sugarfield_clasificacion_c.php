<?php
 // created: 2016-08-25 10:56:50
$dictionary['fact_Facturas']['fields']['clasificacion_c']['labelValue']='Clasificación';

 ?>