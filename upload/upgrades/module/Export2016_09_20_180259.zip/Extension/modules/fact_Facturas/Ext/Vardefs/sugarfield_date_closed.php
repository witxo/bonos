<?php
 // created: 2015-10-27 12:30:52
$dictionary['fact_Facturas']['fields']['date_closed']['options']='date_range_search_dom';
$dictionary['fact_Facturas']['fields']['date_closed']['help']='Fecha de emisi&oacute;n de la factura';
$dictionary['fact_Facturas']['fields']['date_closed']['merge_filter']='disabled';
$dictionary['fact_Facturas']['fields']['date_closed']['reportable']=true;
$dictionary['fact_Facturas']['fields']['date_closed']['enable_range_search']='1';

 ?>