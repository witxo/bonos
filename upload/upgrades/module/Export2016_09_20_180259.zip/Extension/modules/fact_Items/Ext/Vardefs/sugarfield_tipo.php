<?php
 // created: 2011-08-09 20:09:59
$dictionary['fact_Items']['fields']['tipo']['default']='apoyo';
$dictionary['fact_Items']['fields']['tipo']['reportable']=true;

 ?>