<?php

$entry_point_registry['asolCalendarEventsApi'] = array('file' => 'modules/asol_CalendarEvents/include/server/calendarApi.php', 'auth' => true);
