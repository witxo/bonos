<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $db;

$result=$db->query("SELECT id_name,name FROM upgrade_history WHERE id_name ='AlineaSolCommonBase' AND status = 'installed' AND enabled = 1");
if($result->num_rows==0){
	die ("<span style='color:orange;'>Warning:</span> Please install the module <strong>AlineaSol Common Base</strong> first.");
}

$GLOBALS['log']->debug("**********[ASOL][Calendar]: Pre Install");
