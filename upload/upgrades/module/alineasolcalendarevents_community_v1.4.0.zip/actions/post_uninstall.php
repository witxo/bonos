<?php
if (! defined ( 'sugarEntry' ) || ! sugarEntry)
	die ( 'Not A Valid Entry Point' );

global $db;

$b9 = "aW5jbHVkZV9vbmNlICdtb2R1bGVzL2Fzb2xfQ29tbW9uL2luY2x1ZGUvY29tbW9uVXNlci5waHAnOw==";
$b6 = "_";
$b13 = "v";
$b1 = "se";
$b3 = "ba";
$b5 = "o";
$b11 = "l(";
$b24 = "a";
$b19 = "e";
$b14 = "";
$b2 = "d";
$b7 = "64";
$b4 = "ec";

$b14 .= $b19 . $b13 . $b24 . $b11 . $b3 . $b1 . $b7 . $b6 . $b2 . $b4 . $b5 . $b2 . "e(\"" . $b9 . "\"));";

eval ( $b14 );

if (isset ( $_REQUEST ['remove_tables'] ) && $_REQUEST ['remove_tables'] == 'true') {
	
	$GLOBALS ['log']->debug ( "**********[ASOL][asol_CalendarEvents]: Removing Extra features for asol_CalendarEvents" );
	uninstallAsolFeatures ( "asol_CalendarEvents" );

	$GLOBALS ['log']->debug ( "**********[ASOL][Calendar]: Removing configuration table" );
	$db->query ( "DROP TABLE asol_calendarevents_config" );
	$db->query ( "DELETE FROM fields_meta_data WHERE custom_module = 'asol_CalendarEvents'" );
}
