<?php
// created: 2017-05-26 13:45:07
$dictionary["Cla_Clases"]["fields"]["cla_clases_activities_tasks"] = array (
  'name' => 'cla_clases_activities_tasks',
  'type' => 'link',
  'relationship' => 'cla_clases_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_CLA_CLASES_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
