<?php
// created: 2017-05-26 13:45:07
$dictionary["Note"]["fields"]["cla_clases_activities_notes"] = array (
  'name' => 'cla_clases_activities_notes',
  'type' => 'link',
  'relationship' => 'cla_clases_activities_notes',
  'source' => 'non-db',
  'module' => 'Cla_Clases',
  'bean_name' => false,
  'vname' => 'LBL_CLA_CLASES_ACTIVITIES_NOTES_FROM_CLA_CLASES_TITLE',
);
