<?php
// created: 2017-05-26 13:45:07
$dictionary["Cla_Clases"]["fields"]["cla_clases_activities_emails"] = array (
  'name' => 'cla_clases_activities_emails',
  'type' => 'link',
  'relationship' => 'cla_clases_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_CLA_CLASES_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
