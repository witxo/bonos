<?php
// created: 2017-05-26 13:45:07
$dictionary["Cla_Clases"]["fields"]["cla_clases_activities_notes"] = array (
  'name' => 'cla_clases_activities_notes',
  'type' => 'link',
  'relationship' => 'cla_clases_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_CLA_CLASES_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
