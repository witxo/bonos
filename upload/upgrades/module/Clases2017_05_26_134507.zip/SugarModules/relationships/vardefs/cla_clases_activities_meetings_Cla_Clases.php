<?php
// created: 2017-05-26 13:45:07
$dictionary["Cla_Clases"]["fields"]["cla_clases_activities_meetings"] = array (
  'name' => 'cla_clases_activities_meetings',
  'type' => 'link',
  'relationship' => 'cla_clases_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_CLA_CLASES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
