<?php
// created: 2017-05-26 13:45:07
$dictionary["Cla_Clases"]["fields"]["cla_clases_activities_calls"] = array (
  'name' => 'cla_clases_activities_calls',
  'type' => 'link',
  'relationship' => 'cla_clases_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_CLA_CLASES_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
