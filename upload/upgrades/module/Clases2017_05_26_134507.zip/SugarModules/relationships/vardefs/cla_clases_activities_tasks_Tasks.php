<?php
// created: 2017-05-26 13:45:07
$dictionary["Task"]["fields"]["cla_clases_activities_tasks"] = array (
  'name' => 'cla_clases_activities_tasks',
  'type' => 'link',
  'relationship' => 'cla_clases_activities_tasks',
  'source' => 'non-db',
  'module' => 'Cla_Clases',
  'bean_name' => false,
  'vname' => 'LBL_CLA_CLASES_ACTIVITIES_TASKS_FROM_CLA_CLASES_TITLE',
);
