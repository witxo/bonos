<?php
// created: 2017-06-01 18:29:55
$dictionary["Account"]["fields"]["bonos_bonos_accounts"] = array (
  'name' => 'bonos_bonos_accounts',
  'type' => 'link',
  'relationship' => 'bonos_bonos_accounts',
  'source' => 'non-db',
  'module' => 'Bonos_Bonos',
  'bean_name' => 'Bonos_Bonos',
  'side' => 'right',
  'vname' => 'LBL_BONOS_BONOS_ACCOUNTS_FROM_BONOS_BONOS_TITLE',
);
