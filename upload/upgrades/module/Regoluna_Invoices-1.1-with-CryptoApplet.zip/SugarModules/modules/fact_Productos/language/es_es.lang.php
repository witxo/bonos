<?php
/*********************************************************************************
 * 
 * Copyright (C) 2008 Rodrigo Saiz Camarero (http://www.regoluna.com)
 *
 * This file is part of "Regoluna® Spanish Invoices" module.
 *
 * "Regoluna® Spanish Invoices" is free software: you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License as published 
 * by the Free Software Foundation, version 3 of the License.
 *   
 ********************************************************************************/
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Asignado a Usuario con Id',
  'LBL_ASSIGNED_TO_NAME' => 'Asignado a',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Fecha de Creación',
  'LBL_DATE_MODIFIED' => 'Última Modificación',
  'LBL_MODIFIED' => 'Modificado Por',
  'LBL_MODIFIED_ID' => 'Modificado Por Id',
  'LBL_MODIFIED_NAME' => 'Modificado Por Nombre',
  'LBL_CREATED' => 'Creado Por',
  'LBL_CREATED_ID' => 'Creado Por Id',
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Nombre',
  'LBL_CREATED_USER' => 'Creado Por Usuario',
  'LBL_MODIFIED_USER' => 'Modificado Por Usuario',
  'LBL_LIST_FORM_TITLE' => 'Lista de productos',
  'LBL_MODULE_NAME' => 'Productos',
  'LBL_MODULE_TITLE' => 'Productos',
  'LBL_HOMEPAGE_TITLE' => 'Mis Productos',
  'LNK_NEW_RECORD' => 'Definir nuevo producto',
  'LNK_LIST' => 'Productos',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Productos',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_FACT_PRODUCTOS_SUBPANEL_TITLE' => 'Productos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo producto',
  'LBL_TIPO' => 'Tipo',
  'LBL_PRECIO_UD' => 'Precio/Ud',
  'LBL_UNIDAD' => 'Unidad',
);
?>
