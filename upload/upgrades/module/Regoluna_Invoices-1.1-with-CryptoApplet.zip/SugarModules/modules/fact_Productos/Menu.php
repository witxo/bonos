<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 
/*********************************************************************************
 * 
 * Copyright (C) 2008 Rodrigo Saiz Camarero (http://www.regoluna.com)
 *
 * This file is part of "Regoluna® Spanish Invoices" module.
 *
 * "Regoluna® Spanish Invoices" is free software: you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License as published 
 * by the Free Software Foundation, version 3 of the License.
 *   
 ********************************************************************************/

global $mod_strings, $app_strings, $sugar_config;
 
if(ACLController::checkAccess('fact_Productos', 'edit', true))$module_menu[]=Array("index.php?module=fact_Productos&action=EditView&return_module=fact_Productos&return_action=DetailView", $mod_strings['LNK_NEW_RECORD'],"Createfact_Productos", 'fact_Productos');
if(ACLController::checkAccess('fact_Productos', 'list', true))$module_menu[]=Array("index.php?module=fact_Productos&action=index&return_module=fact_Productos&return_action=DetailView", $mod_strings['LNK_LIST'],"fact_Productos", 'fact_Productos');
if(ACLController::checkAccess('fact_Productos', 'import', true))$module_menu[]=Array("index.php?module=Import&action=Step1&import_module=fact_Productos&return_module=fact_Productos&return_action=index", $app_strings['LBL_IMPORT'],"Import", 'fact_Productos');