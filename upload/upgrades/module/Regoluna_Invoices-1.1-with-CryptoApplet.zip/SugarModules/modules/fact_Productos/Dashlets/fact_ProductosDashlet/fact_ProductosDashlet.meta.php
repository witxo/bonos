<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * 
 * Copyright (C) 2008 Rodrigo Saiz Camarero (http://www.regoluna.com)
 *
 * This file is part of "Regoluna® Spanish Invoices" module.
 *
 * "Regoluna® Spanish Invoices" is free software: you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License as published 
 * by the Free Software Foundation, version 3 of the License.
 *   
 ********************************************************************************/
 
global $app_strings;

$dashletMeta['fact_ProductosDashlet'] = array('module'		=> 'fact_Productos',
										  'title'       => translate('LBL_HOMEPAGE_TITLE', 'fact_Productos'), 
                                          'description' => 'A customizable view into fact_Productos',
                                          'icon'        => 'themes/default/images/icon_fact_Productos_32.gif',
                                          'category'    => 'Module Views');
