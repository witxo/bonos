<?PHP
/*********************************************************************************
 * 
 * Copyright (C) 2008 Rodrigo Saiz Camarero (http://www.regoluna.com)
 *
 * This file is part of "Regoluna® Spanish Invoices" module.
 *
 * "Regoluna® Spanish Invoices" is free software: you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License as published 
 * by the Free Software Foundation, version 3 of the License.
 *   
 ********************************************************************************/
require_once('modules/fact_Productos/fact_Productos_sugar.php');
class fact_Productos extends fact_Productos_sugar {
	
	function fact_Productos(){	
		parent::fact_Productos_sugar();
	}
	
}
?>