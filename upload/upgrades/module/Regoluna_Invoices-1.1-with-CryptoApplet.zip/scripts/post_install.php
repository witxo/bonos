<?php
if(!defined('sugarEntry'))define('sugarEntry', true);

function post_install() {
  
  include_once("modules/Administration/QuickRepairAndRebuild.php");
  $RBO = new RepairAndClear();
  $RBO->show_output = true;
  $RBO->clearSmarty();
  //$RBO->clearTpls();
  //$RBO->clearVardefs();

  // Correct Javascript file permissions
  correct_perm('custom/include');
  correct_perm('custom/include/generic');
  correct_perm('custom/include/generic/itemUtils.js');
  correct_perm('include/SugarFields/Fields/NumFactura');
  correct_perm('include/SugarFields/Fields/NumFactura/SugarFieldNumFactura.js');

  correct_perm('custom/themes');
  correct_perm('custom/themes/default');
  correct_perm('custom/themes/default/fact_FacturasStyle.css');
  
  // Check Dependencies
    require_once('custom/modules/Administration/Ext/Language/en_us.lang.ext.php');
  
    // Comprobando GD
    echo "<br/><p>{$mod_strings['LBL_CHECKING_GD']}...   &nbsp;&nbsp;&nbsp;&nbsp;";
    if (extension_loaded('gd') && function_exists('gd_info')) {
      echo "OK </p><p>{$mod_strings['LBL_GD_INSTALLED']}</p>";
    }else{
      echo "ERROR </p><p>{$mod_strings['LBL_GD_NOT_INSTALLED']}</p>";
    }
    
    // Comprobando CryptoApplet
    echo "<br/><br/><p>{$mod_strings['LBL_CHECKING_CRYPTOAPPLET']}...</p>";
    
    $version="2.1.0";
    $archivos=array(
      "uji-ui-applet-{$version}-signed.jar", 
      "uji-config-{$version}-signed.jar", 
      "uji-utils-{$version}-signed.jar", 
      "uji-crypto-core-{$version}-signed.jar", 
      "uji-keystore-{$version}-signed.jar", 
      "uji-crypto-jxades-{$version}-signed.jar",   
      "uji-format-facturae-{$version}-signed.jar",
      "uji-format-pdf-{$version}-signed.jar",
      "lib/bcmail-jdk15-143.jar",
      "lib/bcprov-jdk15-143.jar",
      "lib/bctsp-jdk15-143.jar",
      "lib/commons-logging.jar",
      "lib/itext-1.4.8.jar",
      "lib/jakarta-log4j-1.2.6.jar",
      "lib/jxades-1.0-signed.jar",
      "lib/myxmlsec.jar",
      "lib/xalan-2.7.0.jar",
      "lib/xmlsec.jar ",
    );
    
    echo "<ul>";
    $crypto_ok=true;
    foreach($archivos as $archivo){
      $f = trim("include/CryptoApplet/$archivo");
      echo "<li>$f ... ";
      if( file_exists($f) ){
        echo "OK </li>";
        correct_perm($f);
      }else{
        echo "<span style=\"background-color:red;font-weight:bold;padding:2px;color:#FFF;\">NOT FOUND</span></li>";
        $crypto_ok=false;
      }
    }
    echo "</ul>";
                   
    if ($crypto_ok) {
      echo "<p>{$mod_strings['LBL_CRYPTOAPPLET_INSTALLED']}</p>";
      correct_perm('include/CryptoApplet');
      correct_perm('include/CryptoApplet/lib');
    }else{
      echo "<p>WARNING: Cryptoapplet is not installed. You have to manually download from 
            <a href=\"http://forja.uji.es/frs/?group_id=24\">forja.uji.es</a> and uncompress it in folder: \"include/CryptoApplet\"</p>";
      echo "<p>Electronic signature has been deactivated. To enable it, install CryptoApplet ang \"Check System\" under \"Admin - Regoluna Invoices\"</p>";
      $f=fopen("config_override.php","a+");
      fwrite($f, "\$sugar_config['fact_deactivate_applet'] = true;");
      fclose($f); 
    }
  
}

function correct_perm($path){
  if ( is_dir($path) ){
    $perm = 0755;
  }else{
    $perm = 0644;
  }
  $original = fileperms($path);
  $new = ($original | $perm) & 0777;
  chmod($path,$new);
}