<?php
if (!defined('sugarEntry')) define('sugarEntry', true);

function pre_install() {

  // Cleans previous uninstall (beta 1 bug)
  if (empty($db)) {
    if (!class_exists('PearDatabase')) {
      return;
    }
    $db =& PearDatabase::getInstance();
  }

  if(!$db) return;
  
  $query = "select * from upgrade_history where name='Regoluna_Facturas' and type='module' and status='installed' and (version='0.4' OR version='0.5' OR version='0.6')";
  $result = $db->query($query, false, "Error: ".$query);
  $row = $db->fetchByAssoc($result);
  
  // Remove previous version 0.4-Beta1 or 0.5-Beta2 from Module Loader screen.
  if ($row['id']) {    
      $fichero = $row['filename'];
      $query = "DELETE from upgrade_history where name='Regoluna_Facturas' and type='module' and status='installed' and (version='0.4' OR version='0.5')";
      $db->query($query, false, "Error: ".$query);
      
      // Delete manifest and ZIP
      $manifestFile = str_replace('.zip','-manifest.php',$fichero);
      
      if(file_exists($fichero)) unlink($fichero);
      if(file_exists($manifestFile)) unlink($manifestFile);
  }

}
