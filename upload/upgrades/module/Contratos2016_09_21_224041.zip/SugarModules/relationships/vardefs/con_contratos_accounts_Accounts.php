<?php
// created: 2016-09-21 22:40:41
$dictionary["Account"]["fields"]["con_contratos_accounts"] = array (
  'name' => 'con_contratos_accounts',
  'type' => 'link',
  'relationship' => 'con_contratos_accounts',
  'source' => 'non-db',
  'module' => 'CON_Contratos',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CON_CONTRATOS_ACCOUNTS_FROM_CON_CONTRATOS_TITLE',
);
