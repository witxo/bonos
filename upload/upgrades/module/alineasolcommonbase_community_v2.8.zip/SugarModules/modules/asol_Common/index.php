<?php

global $db, $current_user, $sugar_config, $app_strings, $mod_strings;

require_once("modules/asol_Common/include/commonUtils.php");

$return_action = (isset($_REQUEST['return_action']) ? $_REQUEST['return_action'] : "index");
$return_module = (isset($_REQUEST['return_module']) ? $_REQUEST['return_module'] : "asol_Common");

$userConfiguration = asol_CommonUtils::getUserConfiguration();
$globalConfiguration = asol_CommonUtils::getGlobalConfiguration();

$fiscalMonthInit = (isset($_REQUEST['fiscalMonthInit']) ? $_REQUEST['fiscalMonthInit'] : $userConfiguration['fiscalMonthInit']);
$entriesPerPage = (isset($_REQUEST['entriesPerPage']) ? $_REQUEST['entriesPerPage'] : $userConfiguration['entriesPerPage']);
$pdfOrientation = (isset($_REQUEST['pdfOrientation']) ? $_REQUEST['pdfOrientation'] : $userConfiguration['pdfOrientation']);
$pdfPageFormat = (isset($_REQUEST['pdfPageFormat']) ? $_REQUEST['pdfPageFormat'] : $userConfiguration['pdfPageFormat']);
$calendarType = (isset($_REQUEST['calendarType']) ? $_REQUEST['calendarType'] : $userConfiguration['calendarType']);
$showGregorianEquiv = (isset($_REQUEST['showGregorianEquiv']) ? $_REQUEST['showGregorianEquiv'] : $userConfiguration['showGregorianEquiv']);
$weekStartsOn = (isset($_REQUEST['weekStartsOn']) ? $_REQUEST['weekStartsOn'] : $userConfiguration['weekStartsOn']);
$scalingFactor = (isset($_REQUEST['pdfImgScalingFactor']) ? $_REQUEST['pdfImgScalingFactor'] : $userConfiguration['pdfImgScalingFactor']);
$pdfImgScalingFactor = (($scalingFactor) > 0 ? ($scalingFactor) : 1.20);

$storedFilesTtl = (isset($_REQUEST['storedFilesTtl']) ? $_REQUEST['storedFilesTtl'] : $globalConfiguration['storedFilesTtl']);
$hostName = (isset($_REQUEST['hostName']) ? $_REQUEST['hostName'] : $globalConfiguration['hostName']);

if ($_REQUEST['view'] == 'edit') {
	
	require_once("modules/asol_Common/include/server/views/viewEdit.php");
	
}